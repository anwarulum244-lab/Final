#!/usr/bin/env python3
"""Hitung waktu klausa/kata dari audio (v3) lalu tulis src/timing.ts.

Metode (tanpa ASR, hanya envelope energi + teks naskah):
 1. Deteksi segmen ucapan dari envelope RMS (jeda >= 0,10 dtk memisahkan segmen).
 2. Perkirakan jumlah suku kata tiap segmen dari durasi DAN jumlah puncak suku kata (nuclei) di audio.
 3. DP: tetapkan rentang kata naskah ke tiap segmen (urutan monoton) dengan biaya selisih suku kata,
    ditambah penalti bila jeda panjang jatuh di tengah klausa.
 4. Di dalam segmen, kata dibagi proporsional suku kata (jeda tidak ikut dihitung).
Ini estimasi, bukan transkripsi per kata. Jika ada yang meleset, koreksi manual di CLAUSES.
"""
import re, json, os, wave
import numpy as np
from scipy.signal import butter, sosfiltfilt, find_peaks

HERE = os.path.dirname(os.path.abspath(__file__))
WAV = os.path.join(HERE, "..", "public", "voiceover.wav")
OUT = os.path.join(HERE, "..", "src", "timing.ts")

# (adegan, klausa) — teks persis dari naskah pengguna (JANGAN diubah)
CL = [
("hook","Satu kesalahan baca Al-Qur’an,"),("hook","melahirkan ilmu yang dihafal santri sampai hari ini."),
("era","Abad pertama Hijriah."),("era","Islam meluas,"),("era","dan makin banyak orang non-Arab masuk Islam."),
("era","Kesalahan berbahasa Arab,"),("era","yang disebut lahn,"),("era","mulai merebak."),
("tugas","Khalifah Ali bin Abi Thalib pun menugaskan Abu al-Aswad ad-Du’ali,"),("tugas","untuk meletakkan kaidah dasarnya."),
("harakat","Abu al-Aswad bahkan memberi tanda harakat pada Al-Qur’an."),("harakat","Titik merah di atas huruf,"),("harakat","untuk fathah."),
("harakat","Dari sinilah,"),("harakat","bahasa Arab mulai punya aturan main."),
("ishabah","Dalam kitab al-Ishabah,"),("ishabah","Ibnu Hajar al-Asqalani menyebutkan bahwa Abu al-Aswad adalah orang pertama yang memberi harakat pada mushaf,"),
("ishabah","dan yang meletakkan al-‘Arabiyyah,"),("ishabah","nama awal ilmu ini."),("ishabah","Nama nahwu,"),("ishabah","baru dikenal sepeninggalnya."),
("kubu","Tapi ilmu ini belum selesai."),("kubu","Ia nyaris terbelah jadi dua kubu."),("kubu","Dua kubu itu bernama Basrah dan Kufah."),
("kubu","Di Basrah,"),("kubu","dikenal nama Sibawaih."),("kubu","Di Kufah,"),("kubu","ada al-Kisa’i."),
("kubu","Dua kota,"),("kubu","dua cara pandang,"),("kubu","dan perdebatan yang panjang."),
("tumpuk","Berabad-abad kemudian,"),("tumpuk","kaidah makin menumpuk,"),("tumpuk","dan makin berat dihafal."),
("peta","Lalu muncul seorang ulama Andalusia yang menetap di Damaskus."),("peta","Ibnu Malik."),
("alfiyah","Ibnu Malik menulis karya besar,"),("alfiyah","al-Kafiyah asy-Syafiyah,"),("alfiyah","sekitar dua ribu tujuh ratus lima puluh bait."),
("alfiyah","Terlalu berat bagi banyak pelajar."),("alfiyah","Maka ia memerasnya,"),("alfiyah","menjadi seribu dua bait."),("alfiyah","Itulah Alfiyah."),
("konon","Konon,"),("konon","saat menulis pembukanya,"),("konon","Ibnu Malik menyebut karyanya lebih unggul dari Alfiyah Ibnu Mu’thi."),
("konon","Seketika ia terhenti."),("konon","Paginya,"),("konon","ia buang bait itu,"),("konon","dan menggantinya dengan pujian untuk Ibnu Mu’thi."),
("konon","Ilmu tinggi,"),("konon","hati rendah."),
("wafat","Ibnu Malik wafat di Damaskus,"),("wafat","tahun enam ratus tujuh puluh dua Hijriah."),
("wafat","Tapi bait-baitnya masih dilantunkan,"),("wafat","tujuh abad kemudian."),
("cta","Simpan,"),("cta","dan kirim ke teman sekelas nahwu-mu."),
]

def syl(word):
    w = re.sub(r"[^a-z’‘' ]", "", word.lower().replace("’", "'").replace("‘", "'"))
    w = w.replace("'", " ")
    n = 0
    for part in w.split():
        i = 0
        cnt = 0
        while i < len(part):
            if part[i] in "aiueo":
                j = i
                while j + 1 < len(part) and part[j + 1] in "aiueo" and part[j:j + 2] in ("ai", "au", "oi", "ei"):
                    j += 1
                    break
                cnt += 1
                i = j + 1
            else:
                i += 1
        n += max(1, cnt)
    return max(1, n)

# ── audio ──
wf = wave.open(WAV); sr = wf.getframerate(); nfr = wf.getnframes()
x = np.frombuffer(wf.readframes(nfr), dtype=np.int16).astype(np.float32) / 32768
dur = nfr / sr
hop = int(sr * 0.01)
rms = np.array([np.sqrt(np.mean(x[i:i + hop] ** 2) + 1e-12) for i in range(0, len(x) - hop, hop)])
db = 20 * np.log10(rms + 1e-9)
sp = db > -42
segs = []; start = None; last = None
for i, v in enumerate(sp):
    t = i * 0.01
    if v:
        if start is None: start = t
        last = t
    elif start is not None and t - last >= 0.10:
        segs.append([start, last + 0.01]); start = None
if start is not None: segs.append([start, last + 0.01])
segs = [s for s in segs if s[1] - s[0] >= 0.08]

# nuclei suku kata
sos = butter(4, [250, 3500], btype="band", fs=sr, output="sos")
y = sosfiltfilt(sos, x)
h5 = int(sr * 0.005)
e = np.sqrt(np.convolve(y ** 2, np.ones(h5 * 2) / (h5 * 2), "same"))[::h5]
d5 = 20 * np.log10(e + 1e-9)
d5s = np.convolve(d5, np.ones(10) / 10, "same")
pk, _ = find_peaks(d5s, distance=int(0.09 / 0.005), prominence=2.5, height=-42)
nuc = pk * 0.005

words = []  # (clause, text, syl)
for ci, (_, txt) in enumerate(CL):
    for w in txt.split():
        words.append((ci, w, syl(w)))
NW = len(words)
cum = [0]
for _, _, s in words: cum.append(cum[-1] + s)
clause_end_idx = set()
for k in range(NW):
    if k + 1 == NW or words[k + 1][0] != words[k][0]:
        clause_end_idx.add(k + 1)  # boundary setelah kata k (indeks eksklusif k+1)

tot_speech = sum(b - a for a, b in segs)
R = cum[-1] / tot_speech
nn = [int(((nuc >= a) & (nuc < b)).sum()) for a, b in segs]
K = cum[-1] / max(1, sum(nn))
est = [0.5 * (b - a) * R + 0.5 * n * K for (a, b), n in zip(segs, nn)]
gap_after = [(segs[i + 1][0] - segs[i][1]) if i + 1 < len(segs) else 9.0 for i in range(len(segs))]
M = len(segs)

INF = 1e18
dp = [[INF] * (NW + 1) for _ in range(M + 1)]
bk = [[None] * (NW + 1) for _ in range(M + 1)]
dp[0][0] = 0.0
MAXW = 40
for i in range(M):
    a, b = segs[i]
    d = b - a
    for j in range(NW + 1):
        if dp[i][j] >= INF: continue
        for j2 in range(j, min(NW, j + MAXW) + 1):
            S = cum[j2] - cum[j]
            if j2 == j:
                c = 0.0 if d < 0.35 else 6.0 + est[i]
            else:
                c = (S - est[i]) ** 2 / (est[i] + 2.0)
                if i > 0 and j == 0: c += 50
                # penalti batas klausa
                if j2 in clause_end_idx:
                    if gap_after[i] < 0.2: c += 0.6
                else:
                    if gap_after[i] >= 0.45: c += 3.0
                    elif gap_after[i] >= 0.28: c += 1.0
                # klausa berakhir di tengah segmen
                for jj in range(j + 1, j2):
                    if jj in clause_end_idx: c += 0.3
            v = dp[i][j] + c
            if v < dp[i + 1][j2]:
                dp[i + 1][j2] = v; bk[i + 1][j2] = (i, j)
# harus menghabiskan semua kata
j = NW; i = M
assign = [None] * M
while i > 0:
    pi, pj = bk[i][j]
    assign[pi] = (pj, j)
    i, j = pi, pj

wt = [None] * NW
for si, (j0, j1) in enumerate(assign):
    if j1 <= j0: continue
    a, b = segs[si]
    ws = [words[k][2] + 0.35 for k in range(j0, j1)]
    tot = sum(ws); acc = 0.0
    for k, w in zip(range(j0, j1), ws):
        wt[k] = (a + (b - a) * acc / tot, a + (b - a) * (acc + w) / tot)
        acc += w

clauses = []
for ci in range(len(CL)):
    idx = [k for k in range(NW) if words[k][0] == ci]
    s = wt[idx[0]][0]; e2 = wt[idx[-1]][1]
    clauses.append({"i": ci, "scene": CL[ci][0], "s": round(s, 3), "e": round(e2, 3)})
clauses[0]["s"] = 0.0 if clauses[0]["s"] < 0.9 else clauses[0]["s"]

# ── chunk subtitle: maks 4 kata / 26 huruf, putus di tanda baca ──
MAXW_SUB, MAXC = 4, 26
chunks = []
for ci in range(len(CL)):
    idx = [k for k in range(NW) if words[k][0] == ci]
    groups = []; cur = []
    for k in idx:
        cur.append(k)
        L = sum(len(words[q][1]) + 1 for q in cur)
        if len(cur) >= MAXW_SUB or L >= MAXC:
            groups.append(cur); cur = []
    if cur:
        if groups and len(cur) == 1 and len(groups[-1]) < MAXW_SUB and sum(len(words[q][1]) + 1 for q in groups[-1] + cur) <= MAXC + 6:
            groups[-1] += cur
        else:
            groups.append(cur)
    # seimbangkan bila grup terakhir hanya 1 kata dan sebelumnya 4
    if len(groups) >= 2 and len(groups[-1]) == 1 and len(groups[-2]) >= 3:
        groups[-1].insert(0, groups[-2].pop())
    for g in groups:
        chunks.append({"clause": ci, "s": round(wt[g[0]][0], 3), "e": round(wt[g[-1]][1], 3),
                       "words": [{"t": words[k][1], "s": round(wt[k][0], 3), "e": round(wt[k][1], 3)} for k in g]})

scenes = []
for c in clauses:
    if not scenes or scenes[-1]["key"] != c["scene"]:
        scenes.append({"key": c["scene"], "s": c["s"], "first": c["i"]})
for k, sc in enumerate(scenes):
    sc["e"] = scenes[k + 1]["s"] if k + 1 < len(scenes) else round(dur, 3)
scenes[0]["s"] = 0.0

with open(OUT, "w", encoding="utf-8") as f:
    f.write("// DIHASILKAN oleh scripts/make-timing.py (v3) — jangan diedit manual.\n")
    f.write(f"export const AUDIO_SECONDS = {dur:.3f};\n")
    f.write("export type Word = {t: string; s: number; e: number};\n")
    f.write("export type Chunk = {clause: number; s: number; e: number; words: Word[]};\n")
    f.write("export const CLAUSES: {i: number; scene: string; s: number; e: number}[] = " + json.dumps(clauses) + ";\n")
    f.write("export const CHUNKS: Chunk[] = " + json.dumps(chunks, ensure_ascii=False) + ";\n")
    f.write("export const SCENES: {key: string; s: number; e: number; first: number}[] = " + json.dumps(scenes) + ";\n")

print("segmen", M, "kata", NW, "suku kata", cum[-1], "R=%.2f K=%.2f" % (R, K), "biaya", round(dp[M][NW], 1))
for c, (_, t) in zip(clauses, CL):
    print(f"{c['i']:2d} {c['s']:7.2f}-{c['e']:7.2f} ({c['e']-c['s']:4.1f}s, {sum(words[k][2] for k in range(NW) if words[k][0]==c['i']):2d}syl) {t}")
