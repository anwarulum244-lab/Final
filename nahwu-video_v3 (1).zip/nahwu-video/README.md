# Video: Lahirnya Ilmu Nahwu (Remotion, 9:16, 1080x1920, 30 FPS)

## Render di GitHub
1. Buat repo baru, unggah **seluruh isi folder ini** (termasuk folder `.github`, `public`, dan `package-lock.json`).
2. Buka tab **Actions** → **Render video Nahwu** → **Run workflow**.
3. Setelah selesai, unduh `nahwu-mp4` dari bagian **Artifacts**.

## Render lokal
```
npm ci
npm run dev      # pratinjau di Remotion Studio
npm run render   # hasil: out/nahwu.mp4
```

## Berkas penting
- `public/voiceover.wav` — suara asli Anda (jangan diganti nama).
- `src/timing.ts` — waktu klausa/kata, dihasilkan `scripts/make-timing.py` dari jeda suara.
- `scripts/make-sfx.sh` — pembuat SFX dan backsound sintetis (bebas hak cipta).
- `src/scenes/` — 11 adegan + slide Sumber (3,5 detik setelah suara selesai).

## Menyetel sinkronisasi (v3)
Subtitle dan pergantian adegan dihitung dari jeda suara, bukan transkripsi per kata. Jika ada yang meleset,
ubah angka `s`/`e` pada `CLAUSES` di `src/timing.ts` (satuan detik), atau jalankan ulang `npm run timing`.

## Efek sinematik (v2)
Bingkai emas yang menggambar diri, pola geometri Islami berparalaks, bokeh dan debu emas berlapis (belakang/depan),
teks emas gradien berkilau, transisi blur + sapuan cahaya, percikan cahaya dan lens streak di momen kunci,
gerak kamera halus, gradasi warna teal-oranye, butiran film, dan vinyet.
Render v2 lebih berat dari v1; di GitHub Actions perkirakan 20–45 menit.

## Peningkatan visual & sinkronisasi (v3)
- `scripts/make-timing.py` ditulis ulang: segmen ucapan nyata dari envelope audio + jumlah suku kata naskah (DP). Timing v2 meleset hingga ±5 dtk di 44 dari 58 klausa. Ini estimasi, bukan transkripsi per kata.
- `src/timingLegacy.ts`: salinan timing awal. `LEGACY_SFX_TIMING` di `Video.tsx` mengembalikan cue SFX ke frame awal.
- Adegan Basrah–Kufah memakai peta asli (`public/img/peta_perkamen.jpg`, 2× dari assets/01) + overlay SVG (`src/scenes/MapBasrahKufah.tsx`). Koordinat titik adalah perkiraan; konfirmasi visual.
- Adegan al-Iṣābah: kutipan Arab (ditulis kode) dengan garis bawah emas pada «ونقط المصاحف».
- Alfiyah: angka kinetik `KineticNumber` (2.750 untuk al-Kafiyah, 1.002 untuk Alfiyah; tanpa angka perantara).
- Siluet baru (`Silhouette.tsx`, SVG, tanpa detail wajah) dengan rim light emas statis; latar `Serambi.tsx`.
- Audio (`voiceover.wav`, `pad.mp3`, `sfx/*.wav`) tidak diubah (checksum identik).

## Penyederhanaan efek (v3.1)
Dibuang: butiran film (grain), blur pada adegan/teks, sorotan cahaya yang menyapu, getaran dan rotasi kamera, garis glitch, sinar berputar. Dikurangi: partikel, bokeh, percikan, flash. Tersisa gerak halus: fade, zoom pelan, rim light statis, kamera peta.

## Gaya elegan (v3.2)
Judul memakai serif Cormorant Garamond (huruf berjarak, tanpa slam/kilatan); subtitle Poppins 600 tanpa pembesaran kata; Flash dan Burst dimatikan; siluet digambar ulang dengan lipatan jubah tipis dan bayangan lantai; palet emas lebih tenang.

## Gaya elegan & aset dari pengguna (v3.2)
- Judul memakai serif Cormorant Garamond (huruf berjarak), subtitle Poppins 600 lebih halus, kilatan/percikan dimatikan.
- Tokoh memakai siluet dari pengguna (PNG transparan tanpa teks label, `public/img/sil_*.png`): Ali = klasik, Abu al-Aswad dan al-Kisa'i = birwibawa, Sibawaih = muda, Ibnu Malik = tua. Ganti lewat prop `who` pada `<Silhouette>`.
- Perpindahan Ibnu Malik memakai peta pengguna `public/img/peta_andalusia_damaskus.jpg` (tidak diubah) di `src/scenes/PetaAndalusia.tsx`; garis emas mengikuti garis putus-putus pada peta.
