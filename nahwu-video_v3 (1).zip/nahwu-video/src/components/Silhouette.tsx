import React from 'react';
import {Img, interpolate, staticFile} from 'remotion';
import {C, Latin, Serif, useAnim} from '../lib';

/** Siluet milik pengguna (PNG transparan, tanpa teks label). Semua menghadap ke kanan; `flip` membalik. */
export type Who = 'klasik' | 'birwibawa' | 'muda' | 'tua';
const SIL: Record<Who, {src: string; w: number; h: number}> = {
  klasik: {src: 'img/sil_klasik.png', w: 446, h: 760},
  birwibawa: {src: 'img/sil_birwibawa.png', w: 494, h: 760},
  muda: {src: 'img/sil_muda.png', w: 486, h: 760},
  tua: {src: 'img/sil_tua.png', w: 545, h: 760},
};
const BASE_H = 560; // tinggi tampil pada scale 1

type Props = {
  x: number;
  y: number;
  scale?: number;
  who?: Who;
  opacity?: number;
  label?: string;
  sub?: string;
  /** warna rim light (default emas) */
  rim?: string;
  flip?: boolean;
  /** frame absolut: rim light masuk perlahan */
  rimAt?: number;
  /** frame absolut: rim light mulai memudar */
  rimUntil?: number;
  // dipertahankan demi kompatibilitas pemanggil lama (diabaikan)
  pose?: string;
  gesture?: boolean;
  turban?: boolean;
  beard?: boolean;
};

const hex2rgba = (hex: string, a: number) => {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${Math.max(0, Math.min(1, a))})`;
};

/**
 * Siluet tokoh dari gambar pengguna, dengan rim light emas tipis yang statis:
 * masuk perlahan → bertahan → memudar. Tidak ada cahaya yang berlari. Ilustrasi simbolis, bukan potret autentik.
 */
export const Silhouette: React.FC<Props> = ({x, y, scale = 1, who = 'birwibawa', opacity = 1, label, sub, rim = C.gold, flip, rimAt, rimUntil}) => {
  const {f} = useAnim();
  const rin = rimAt === undefined ? 1 : interpolate(f, [rimAt, rimAt + 34], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rout = rimUntil === undefined ? 0 : interpolate(f, [rimUntil, rimUntil + 28], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const lvl = rin * (1 - rout);
  const d = SIL[who];
  const H0 = BASE_H;
  const W0 = Math.round((d.w / d.h) * H0);
  const dir = flip ? -1 : 1;
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%, -50%) scale(${scale})`, opacity, textAlign: 'center'}}>
      <div
        style={{
          width: W0,
          height: H0,
          margin: '0 auto',
          filter: `drop-shadow(${3 * dir}px -1px 0 ${hex2rgba(rim, 0.9 * lvl)}) drop-shadow(${7 * dir}px 0 12px ${hex2rgba(rim, 0.36 * lvl)})`,
        }}
      >
        <Img
          src={staticFile(d.src)}
          style={{
            width: W0,
            height: H0,
            display: 'block',
            transform: flip ? 'scaleX(-1)' : undefined,
            WebkitMaskImage: 'linear-gradient(to bottom, #000 82%, transparent 100%)',
            maskImage: 'linear-gradient(to bottom, #000 82%, transparent 100%)',
          }}
        />
      </div>
      {label && (
        <div style={{...Serif, marginTop: 10 / scale, fontWeight: 600, fontSize: 44, letterSpacing: 2, color: C.cream, textShadow: '0 3px 14px #000', lineHeight: 1.1}}>
          {label}
          {sub && <div style={{...Latin, fontWeight: 400, fontSize: 22, letterSpacing: 5, color: C.gold, marginTop: 6, textTransform: 'uppercase'}}>{sub}</div>}
        </div>
      )}
    </div>
  );
};
