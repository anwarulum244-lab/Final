import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {C, Latin, Serif, useAnim} from '../lib';

/** Pembungkus adegan: fade masuk/keluar + zoom pelan (Ken Burns). */
export const SceneWrap: React.FC<{dur: number; children: React.ReactNode; zoom?: number}> = ({dur, children, zoom = 0.06}) => {
  const {local} = useAnim();
  const o = interpolate(local, [0, 10, dur - 9, dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
    const s = 1 + (local / Math.max(1, dur)) * Math.min(zoom, 0.03);
  return (
    <AbsoluteFill style={{opacity: o, transform: `scale(${s})`}}>{children}</AbsoluteFill>
  );
};

export const Tag: React.FC<{text: string; at: number}> = ({text, at}) => {
  const {ease} = useAnim();
  const e = ease(at, 20);
  return (
    <div style={{position: 'absolute', top: 176, left: 0, right: 0, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 24, opacity: e}}>
      <div style={{width: 70 * e, height: 1, background: `linear-gradient(90deg, transparent, ${C.gold})`}} />
      <span style={{...Latin, fontWeight: 500, fontSize: 24, letterSpacing: 11, color: '#f3dfa8'}}>{text}</span>
      <div style={{width: 70 * e, height: 1, background: `linear-gradient(270deg, transparent, ${C.gold})`}} />
    </div>
  );
};

/** Judul besar: serif ringan, huruf berjarak, muncul dengan fade + naik tipis. Tanpa kilatan/slam. */
export const Big: React.FC<{
  text: string; at: number; y: number; size?: number; color?: string; glow?: boolean; slam?: boolean; weight?: number; letter?: number;
}> = ({text, at, y, size = 120, color = C.cream, glow = true, weight = 600, letter = 4}) => {
  const {ease} = useAnim();
  const e = ease(at, 22);
  const col = color === C.gold ? '#f0d58f' : color === C.cream ? '#f6ecd6' : color;
  return (
    <div
      style={{
        position: 'absolute', left: 40, right: 40, top: y, textAlign: 'center', ...Serif,
        fontWeight: weight, fontSize: size * 1.08, lineHeight: 1.05, letterSpacing: letter, textTransform: 'uppercase', fontVariantNumeric: 'lining-nums', fontFeatureSettings: '"lnum" 1',
        color: col, opacity: e, transform: `translateY(${(1 - e) * 16}px)`,
        textShadow: glow ? `0 0 28px ${col}33, 0 4px 20px rgba(0,0,0,0.85)` : '0 4px 20px rgba(0,0,0,0.85)',
      }}
    >
      {text}
    </div>
  );
};

export const Small: React.FC<{text: string; at: number; y: number; size?: number; color?: string}> = ({text, at, y, size = 38, color = C.cream}) => {
  const {ease} = useAnim();
  const e = ease(at, 20);
  return (
    <div style={{position: 'absolute', left: 60, right: 60, top: y, textAlign: 'center', ...Latin, fontWeight: 500, fontSize: size * 0.85, letterSpacing: 4, color, opacity: e, transform: `translateY(${(1 - e) * 12}px)`, textShadow: '0 3px 14px #000'}}>
      {text}
    </div>
  );
};

/** Dulu kilatan layar; kini dimatikan agar tenang. Tetap diekspor demi kompatibilitas. */
export const Flash: React.FC<{at: number; color?: string}> = () => null;
