import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, staticFile} from 'remotion';
import {Arabic, C, H, Latin, Serif, W, cs, useAnim, wordStart} from '../lib';
import {Silhouette} from '../components/Silhouette';
import {Big} from '../components/ui';

/**
 * Adegan peta Basrah–Kufah.
 * - Peta dasar = peta perkamen asli milik pengguna (public/img/peta_perkamen.jpg, versi 2× dari assets/01).
 * - Titik, label Arab, pulse, glow, garis penanda, dan cincin wilayah = SVG/HTML buatan kode (bukan gambar).
 * - Cincin wilayah menyala lalu BERHENTI (static hold). Tidak ada garis penghubung Basrah–Kufah.
 *
 * Koordinat titik dalam piksel peta asli (857×1536). Dihitung dari kalibrasi lintang/bujur terhadap
 * Siprus, Teluk Persia, dan Selat Bab al-Mandab pada peta; perkiraan, LAYAK DIKONFIRMASI visual oleh pengguna.
 */
const MAP_W = 857;
const MAP_H = 1536;
const S0 = W / MAP_W;
export const BASRAH = {x: 630, y: 498};
export const KUFAH = {x: 519, y: 438};
const MID = {x: (BASRAH.x + KUFAH.x) / 2, y: (BASRAH.y + KUFAH.y) / 2};

type Cam = {f: number; cx: number; cy: number; z: number};
const camFor = (P: {x: number; y: number}, z: number, screenY: number): Omit<Cam, 'f'> => {
  const k = S0 * z;
  return {cx: P.x, cy: P.y + (H / 2 - screenY) / k, z};
};

const inOut = Easing.inOut(Easing.cubic);

const GOLD_T = '#ffe9b0';

const Marker: React.FC<{x: number; y: number; at: number; ar: string; lat: string; side: 'above' | 'below'; ringR: number}> = ({x, y, at, ar, lat, side, ringR}) => {
  const {f, ease} = useAnim();
  const lit = ease(at, 12);
  if (f < at - 1) return null;
  const sgn = side === 'above' ? -1 : 1;
  const circ = 2 * Math.PI * ringR;
  const draw = interpolate(f, [at + 4, at + 34], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const lineP = interpolate(f, [at + 8, at + 26], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const labelE = ease(at + 14, 14);
  const vis = interpolate(x, [-60, 150, 760, 960], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) * interpolate(y, [-60, 260, 1250, 1450], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', opacity: vis}}>
        <defs>
          <radialGradient id={`mk${lat}`} cx="50%" cy="50%" r="50%">
            <stop offset="0" stopColor="#fff3c4" stopOpacity={0.95} />
            <stop offset="0.35" stopColor={C.gold} stopOpacity={0.55} />
            <stop offset="1" stopColor={C.orange} stopOpacity={0} />
          </radialGradient>
        </defs>
        {/* area wilayah: menyala lalu berhenti */}
        <circle cx={x} cy={y} r={ringR} fill={C.gold} fillOpacity={0.08 * draw} stroke={C.gold} strokeWidth={3} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - draw)} transform={`rotate(-90 ${x} ${y})`} style={{filter: `drop-shadow(0 0 10px ${C.orange})`}} opacity={0.95} />
        {/* glow */}
        <circle cx={x} cy={y} r={64 + Math.sin(f / 9) * 4} fill={`url(#mk${lat})`} opacity={lit} />
        {/* pulse */}
        {[0, 1].map((k) => {
          const p = (((f - at - k * 24) % 64) + 64) % 64 / 64;
          const on = f >= at + k * 24;
          return <circle key={k} cx={x} cy={y} r={14 + p * 74} fill="none" stroke={C.gold} strokeWidth={4 - 2.4 * p} opacity={on ? (1 - p) * 0.85 * lit : 0} />;
        })}
        {/* garis penanda */}
        <line x1={x} y1={y + sgn * 22} x2={x} y2={y + sgn * (22 + 74 * lineP)} stroke={GOLD_T} strokeWidth={3} style={{filter: `drop-shadow(0 0 6px ${C.orange})`}} />
        {/* titik */}
        <circle cx={x} cy={y} r={15 * lit} fill={C.gold} stroke="#2a1604" strokeWidth={3} style={{filter: `drop-shadow(0 0 14px ${C.orange})`}} />
        <circle cx={x} cy={y} r={5.5 * lit} fill="#fff" />
      </svg>
      <div
        style={{
          position: 'absolute',
          left: x - 190,
          width: 380,
          top: side === 'above' ? y - 98 - 150 : y + 98,
          textAlign: 'center',
          opacity: labelE * vis,
          transform: `translateY(${(1 - labelE) * 14 * sgn}px) scale(${0.92 + 0.08 * labelE})`,
        }}
      >
        <div style={{display: 'inline-block', padding: '4px 30px 10px', borderRadius: 26, background: 'rgba(5,9,22,0.74)', border: `2px solid ${C.gold}cc`, boxShadow: `0 0 30px ${C.orange}66`}}>
          <div style={{...Arabic, fontSize: 98, lineHeight: 1.12, fontWeight: 700, color: C.gold, textShadow: `0 0 22px ${C.orange}`}}>{ar}</div>
          <div style={{...Latin, fontWeight: 700, fontSize: 30, letterSpacing: 9, color: C.cream, marginTop: -2}}>{lat}</div>
        </div>
      </div>
    </>
  );
};

const Person: React.FC<{x: number; at: number; flip?: boolean; name: string; ar: string; dim?: number; who: 'muda' | 'birwibawa'}> = ({x, at, flip, name, ar, dim = 1, who}) => {
  const {ease} = useAnim();
  const e = ease(at, 18);
  const e2 = ease(at + 8, 16);
  return (
    <>
      <Silhouette who={who} x={x} y={1120 + (1 - e) * 46} scale={0.62} flip={flip} opacity={e * dim} rimAt={at + 4} />
      <div style={{position: 'absolute', left: x - 200, width: 400, top: 1332, textAlign: 'center', opacity: e2 * dim}}>
        <div style={{...Arabic, fontSize: 46, fontWeight: 700, color: C.gold, lineHeight: 1.1, textShadow: `0 0 18px ${C.orange}`}}>{ar}</div>
        <div style={{...Serif, fontWeight: 600, fontSize: 38, letterSpacing: 2, color: C.cream, textShadow: '0 3px 14px #000', marginTop: 2}}>{name}</div>
      </div>
    </>
  );
};

export const MapBasrahKufah: React.FC<{dur: number}> = ({dur}) => {
  const {f, ease} = useAnim();
  const t23 = cs(23), t24 = cs(24), t26 = cs(26), t28 = cs(28);
  const endF = t28 + 40 + 400;
  const KEYS: Cam[] = [
    {f: t23 - 12, cx: 470, cy: 640, z: 1.15},
    {f: t24 - 16, ...camFor(MID, 2.0, 780)},
    {f: t24 + 12, ...camFor(BASRAH, 3.3, 700)},
    {f: t26 - 30, ...camFor(BASRAH, 3.3, 700)},
    {f: t26 + 10, ...camFor(KUFAH, 3.3, 700)},
    {f: t28 - 8, ...camFor(KUFAH, 3.3, 700)},
    {f: t28 + 42, ...camFor(MID, 2.4, 780)},
    {f: endF, ...camFor(MID, 2.5, 780)},
  ];
  let cam: Cam = KEYS[0];
  if (f >= KEYS[KEYS.length - 1].f) cam = KEYS[KEYS.length - 1];
  else if (f > KEYS[0].f) {
    for (let i = 0; i < KEYS.length - 1; i++) {
      const a = KEYS[i], b = KEYS[i + 1];
      if (f >= a.f && f <= b.f) {
        const p = inOut((f - a.f) / Math.max(1, b.f - a.f));
        cam = {f, cx: a.cx + (b.cx - a.cx) * p, cy: a.cy + (b.cy - a.cy) * p, z: a.z + (b.z - a.z) * p};
        break;
      }
    }
  }
  const drift = {x: Math.sin(f / 70) * 2.2, y: Math.cos(f / 85) * 2.2};
  const cx = cam.cx + drift.x, cy = cam.cy + drift.y;
  const k = S0 * cam.z;
  const proj = (P: {x: number; y: number}) => ({x: W / 2 + k * (P.x - cx), y: H / 2 + k * (P.y - cy)});
  const pB = proj(BASRAH), pK = proj(KUFAH);
  const ringR = 24 * k;

  const tSib = wordStart(25, /Sibawaih/);
  const tKis = wordStart(27, /Kisa/);
  const kisIn = f >= tKis - 8;

  return (
    <AbsoluteFill>
      {/* peta asli pengguna sebagai dasar */}
      <AbsoluteFill style={{background: '#1b1209'}}>
        <div style={{position: 'absolute', left: 0, top: 0, width: MAP_W, height: MAP_H, transformOrigin: '0 0', transform: `translate(${W / 2 - k * cx}px, ${H / 2 - k * cy}px) scale(${k})`}}>
          <Img src={staticFile('img/peta_perkamen.jpg')} style={{width: MAP_W, height: MAP_H, display: 'block'}} />
        </div>
      </AbsoluteFill>
      {/* penggelapan agar siluet & subtitle terbaca, serta vinyet sinematik */}
      <AbsoluteFill style={{background: 'linear-gradient(0deg, rgba(3,6,14,0.96) 0%, rgba(3,6,14,0.78) 24%, rgba(3,6,14,0.08) 52%, rgba(3,6,14,0.22) 100%)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 38%, transparent 38%, rgba(0,0,0,0.6) 100%)'}} />

      {/* marker, label, cincin wilayah (SVG/HTML terpisah dari peta) */}
      <Marker x={pB.x} y={pB.y} at={t24} ar="البصرة" lat="BASRAH" side="above" ringR={ringR} />
      <Marker x={pK.x} y={pK.y} at={t26} ar="الكوفة" lat="KUFAH" side="above" ringR={ringR} />

      {/* siluet: Sibawaih (Basrah, timur/kanan) dan al-Kisā’ī (Kufah, barat/kiri) */}
      <Person who="muda" x={800} at={tSib - 6} flip name="Sibawaih" ar="سيبويه" dim={kisIn ? 0.78 : 1} />
      <Person who="birwibawa" x={280} at={tKis - 6} name="al-Kisa’i" ar="الكسائي" />
      <Big text="PERDEBATAN YANG PANJANG" at={cs(30)} y={268} size={58} color={C.cream} slam={false} />
    </AbsoluteFill>
  );
};
