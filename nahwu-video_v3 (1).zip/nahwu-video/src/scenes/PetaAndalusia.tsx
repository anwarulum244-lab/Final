import React from 'react';
import {AbsoluteFill, Easing, Img, interpolate, staticFile} from 'remotion';
import {Arabic, C, H, Latin, Serif, W, cs, useAnim, wordStart} from '../lib';
import {Silhouette} from '../components/Silhouette';
import {SceneWrap, Tag} from '../components/ui';

/**
 * Perpindahan Ibnu Malik: Andalusia → Damaskus, memakai peta milik pengguna
 * (public/img/peta_andalusia_damaskus.jpg, tidak diubah). Garis emas, titik, dan label dibuat kode (SVG/HTML).
 * Titik rute ditelusuri dari garis putus-putus pada peta itu sendiri (koordinat piksel 2576×1438); ujungnya masuk ke titik Damaskus.
 */
const MAP_W = 2576;
const MAP_H = 1438;
const S0 = H / MAP_H;
const ROUTE: [number, number][] = [
  [390, 620], [330, 640], [266, 658], [287, 686], [303, 714], [312, 727], [337, 729], [375, 735], [412, 742],
  [456, 744], [500, 739], [544, 730], [587, 714], [631, 700], [675, 689], [725, 683], [775, 679], [825, 677],
  [875, 674], [912, 674], [956, 677], [1017, 687], [1070, 703], [1117, 723], [1150, 747], [1177, 773], [1200, 800],
  [1230, 833], [1263, 867], [1303, 893], [1350, 909], [1403, 920], [1457, 930], [1510, 937], [1563, 943], [1617, 951],
  [1663, 959], [1717, 972], [1783, 993], [1850, 1008], [1917, 1029], [1950, 1031], [1977, 1017], [2003, 977], [2037, 943],
  [2083, 928], [2137, 925], [2183, 930], [2203, 935], [2240, 892], [2275, 851],
];
const CUM: number[] = [0];
for (let i = 1; i < ROUTE.length; i++) CUM.push(CUM[i - 1] + Math.hypot(ROUTE[i][0] - ROUTE[i - 1][0], ROUTE[i][1] - ROUTE[i - 1][1]));
const TOTAL = CUM[CUM.length - 1];
const posAt = (p: number) => {
  const d = Math.max(0, Math.min(1, p)) * TOTAL;
  for (let i = 1; i < CUM.length; i++) {
    if (d <= CUM[i]) {
      const t = (d - CUM[i - 1]) / Math.max(1e-6, CUM[i] - CUM[i - 1]);
      return {x: ROUTE[i - 1][0] + (ROUTE[i][0] - ROUTE[i - 1][0]) * t, y: ROUTE[i - 1][1] + (ROUTE[i][1] - ROUTE[i - 1][1]) * t, seg: i};
    }
  }
  return {x: ROUTE[ROUTE.length - 1][0], y: ROUTE[ROUTE.length - 1][1], seg: ROUTE.length};
};

const Pin: React.FC<{x: number; y: number; at: number; ar: string; lat: string}> = ({x, y, at, ar, lat}) => {
  const {f, ease} = useAnim();
  if (f < at - 1) return null;
  const lit = ease(at, 12);
  const labelE = ease(at + 10, 14);
  const vis = interpolate(x, [-60, 160, 920, 1140], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', opacity: vis}}>
        {[0, 1].map((k) => {
          const p = (((f - at - k * 24) % 64) + 64) % 64 / 64;
          return <circle key={k} cx={x} cy={y} r={14 + p * 70} fill="none" stroke={C.gold} strokeWidth={4 - 2.4 * p} opacity={f >= at + k * 24 ? (1 - p) * 0.85 * lit : 0} />;
        })}
        <circle cx={x} cy={y} r={15 * lit} fill={C.gold} stroke="#2a1604" strokeWidth={3} style={{filter: `drop-shadow(0 0 12px ${C.orange})`}} />
        <circle cx={x} cy={y} r={5.5 * lit} fill="#fff" />
        <line x1={x} y1={y - 22} x2={x} y2={y - 22 - 70 * labelE} stroke="#ffe9b0" strokeWidth={3} />
      </svg>
      <div style={{position: 'absolute', left: x - 190, width: 380, top: y - 98 - 150, textAlign: 'center', opacity: labelE * vis, transform: `translateY(${(1 - labelE) * 14}px)`}}>
        <div style={{display: 'inline-block', padding: '4px 30px 10px', borderRadius: 26, background: 'rgba(5,9,22,0.76)', border: `2px solid ${C.gold}cc`}}>
          <div style={{...Arabic, fontSize: 92, lineHeight: 1.12, fontWeight: 700, color: C.gold}}>{ar}</div>
          <div style={{...Latin, fontWeight: 700, fontSize: 28, letterSpacing: 9, color: C.cream, marginTop: -2}}>{lat}</div>
        </div>
      </div>
    </>
  );
};

export const Peta: React.FC<{dur: number}> = ({dur}) => {
  const {f, ease} = useAnim();
  const t0 = cs(34) + 6;
  const t1 = Math.max(t0 + 40, wordStart(34, /Damaskus/) + 8);
  const tAnd = Math.max(cs(34) + 4, wordStart(34, /Andalusia/) - 4);
  const p = interpolate(f, [t0, t1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
  const head = posAt(p);
  const z = 1.55 - 0.42 * Math.sin(Math.PI * p);
  const k = S0 * z;
  // kamera dijaga agar tidak keluar dari tepi peta
  const hw = W / 2 / k, hh = H / 2 / k;
  const cx = Math.max(hw + 12, Math.min(MAP_W - hw - 12, head.x));
  const cy = Math.max(hh + 12, Math.min(MAP_H - hh - 12, head.y + (H / 2 - 780) / k));
  const proj = (x: number, y: number) => ({x: W / 2 + k * (x - cx), y: H / 2 + k * (y - cy)});
  // garis emas sebagian sampai kepala
  const pts: string[] = [];
  const s0 = proj(ROUTE[0][0], ROUTE[0][1]);
  pts.push(`${s0.x},${s0.y}`);
  for (let i = 1; i < head.seg && i < ROUTE.length; i++) {
    const q = proj(ROUTE[i][0], ROUTE[i][1]);
    pts.push(`${q.x},${q.y}`);
  }
  const hd = proj(head.x, head.y);
  pts.push(`${hd.x},${hd.y}`);
  const pA = proj(ROUTE[0][0], ROUTE[0][1]);
  const pD = proj(ROUTE[ROUTE.length - 1][0], ROUTE[ROUTE.length - 1][1]);
  const tDam = t1 - 8;
  const nameE = ease(cs(35), 16);
  const nameE2 = ease(cs(35) + 8, 16);
  return (
    <SceneWrap dur={dur}>
      <AbsoluteFill style={{background: '#1b1209'}}>
        <div style={{position: 'absolute', left: 0, top: 0, width: MAP_W, height: MAP_H, transformOrigin: '0 0', transform: `translate(${W / 2 - k * cx}px, ${H / 2 - k * cy}px) scale(${k})`}}>
          <Img src={staticFile('img/peta_andalusia_damaskus.jpg')} style={{width: MAP_W, height: MAP_H, display: 'block'}} />
        </div>
      </AbsoluteFill>
      <AbsoluteFill style={{background: 'linear-gradient(0deg, rgba(3,6,14,0.96) 0%, rgba(3,6,14,0.78) 24%, rgba(3,6,14,0.08) 52%, rgba(3,6,14,0.22) 100%)'}} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 38%, transparent 38%, rgba(0,0,0,0.6) 100%)'}} />
      {p > 0 && (
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          <polyline points={pts.join(' ')} fill="none" stroke={C.gold} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" opacity={0.95} style={{filter: `drop-shadow(0 0 10px ${C.orange})`}} />
          {p < 1 && <circle cx={hd.x} cy={hd.y} r={13} fill="#fff" style={{filter: `drop-shadow(0 0 12px ${C.gold})`}} />}
        </svg>
      )}
      <Pin x={pA.x} y={pA.y} at={tAnd} ar="الأندلس" lat="ANDALUSIA" />
      <Pin x={pD.x} y={pD.y} at={tDam} ar="دمشق" lat="DAMASKUS" />
      <Tag text="ULAMA ANDALUSIA" at={cs(34)} />
      <Silhouette who="tua" x={W / 2} y={1120 + (1 - nameE) * 46} scale={0.62} opacity={nameE} rimAt={cs(35) + 2} />
      <div style={{position: 'absolute', left: W / 2 - 220, width: 440, top: 1332, textAlign: 'center', opacity: nameE2}}>
        <div style={{...Arabic, fontSize: 50, fontWeight: 700, color: C.gold, lineHeight: 1.1, textShadow: `0 0 18px ${C.orange}`}}>ابن مالك</div>
        <div style={{...Serif, fontWeight: 600, fontSize: 40, letterSpacing: 2, color: C.cream, textShadow: '0 3px 14px #000', marginTop: 2}}>Ibnu Malik</div>
      </div>
    </SceneWrap>
  );
};
