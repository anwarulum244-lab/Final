import React from 'react';
import {AbsoluteFill, Easing, interpolate} from 'remotion';
import {Arabic, C, H, Latin, W, ce, cs, rnd, useAnim, wordStart} from '../lib';
import {MapBasrahKufah} from './MapBasrahKufah';
import {Big, Flash, SceneWrap, Small, Tag} from '../components/ui';
import {Silhouette} from '../components/Silhouette';
import {Burst, Streak} from '../components/Ornament';

/* ───────── 5. AL-ISHABAH ───────── */
/** Kutipan terverifikasi oleh pengguna: al-Iṣābah fī Tamyīz aṣ-Ṣaḥābah, juz 3, hlm. 456. Teks Arab ditulis kode, bukan gambar. */
const Q_BEFORE = '«وقال أبو علي القاليّ: حدثنا أبو إسحاق الزجاج، حدثنا أبو العباس المبرد، قال: أول من وضع العربية ';
const Q_PHRASE = 'ونقط المصاحف';
const Q_AFTER = ' أبو الأسود، وقد سئل أبو الأسود عمّن نهج له الطريق، فقال: تلقيته عن علي بن أبي طالب.»';
const Q_REF = 'الإصابة في تمييز الصحابة، ج ٣، ص ٤٥٦';

export const Ishabah: React.FC<{dur: number}> = ({dur}) => {
  const {f, ease, spr} = useAnim();
  const bookS = spr(cs(15), 13, 130);
  // kartu kutipan: masuk di "Dalam kitab al-Ishabah", teks terungkap mengikuti klausa 16
  const cardE = ease(cs(15) + 14, 14);
  const reveal = interpolate(f, [cs(16), ce(16) - 4], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  // garis bawah emas pada «ونقط المصاحف» saat narator menyebut "memberi harakat pada mushaf"
  const ulAt = wordStart(16, /memberi/);
  const ul = interpolate(f, [ulAt, ulAt + 18], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const hl = ease(ulAt, 12);
  const glow = f >= ulAt + 18 ? 0.55 + 0.45 * Math.max(0, 1 - (f - ulAt - 18) / 36) : 0.2 * ul; // menyala lembut lalu tenang
  const refE = ease(ulAt + 22, 14);
  return (
    <SceneWrap dur={dur}>
      <Tag text="RUJUKAN KITAB" at={cs(15)} />
      {/* pelat judul kitab (tipografi, bukan scan) */}
      <div style={{position: 'absolute', left: 120, right: 120, top: 262, height: 150, borderRadius: 20, background: 'linear-gradient(135deg,#143a2f,#0a2019)', border: `3px solid ${C.gold}`, boxShadow: `0 0 50px ${C.gold}55, 8px 10px 0 #04100c`, transform: `scale(${0.5 + 0.5 * bookS})`, opacity: ease(cs(15), 8), textAlign: 'center', paddingTop: 10}}>
        <div style={{...Arabic, fontSize: 64, color: C.gold, lineHeight: 1.15, fontWeight: 700}}>الإصابة في تمييز الصحابة</div>
        <div style={{...Latin, fontWeight: 600, fontSize: 28, color: C.cream, marginTop: 2}}>Ibnu Hajar al-Asqalani</div>
      </div>
      {/* kartu kutipan Arab */}
      <div style={{position: 'absolute', left: 70, right: 70, top: 452, opacity: cardE, transform: `translateY(${(1 - cardE) * 40}px)`, padding: '30px 38px 34px', borderRadius: 26, background: 'rgba(7,13,32,0.9)', border: `3px solid ${C.gold}99`, boxShadow: `0 0 46px ${C.gold}33, inset 0 0 40px rgba(0,0,0,0.5)`}}>
        <div
          style={{
            ...Arabic,
            fontSize: 49,
            lineHeight: 1.95,
            color: C.cream,
            textAlign: 'justify',
            textAlignLast: 'right',
            WebkitMaskImage: `linear-gradient(to bottom, #000 ${reveal * 100}%, transparent ${Math.min(100, reveal * 100 + 10)}%)`,
            maskImage: `linear-gradient(to bottom, #000 ${reveal * 100}%, transparent ${Math.min(100, reveal * 100 + 10)}%)`,
          }}
        >
          {Q_BEFORE}
          <span style={{position: 'relative', display: 'inline-block', whiteSpace: 'nowrap', color: hl > 0.02 ? '#ffd877' : C.cream, textShadow: hl > 0.02 ? `0 0 ${24 * glow}px ${C.orange}` : undefined, fontWeight: 700}}>
            {Q_PHRASE}
            <span style={{position: 'absolute', right: 0, bottom: 4, height: 7, width: `${ul * 100}%`, borderRadius: 4, background: `linear-gradient(270deg, #fff3c4, ${C.gold} 40%, #c4801f)`, boxShadow: `0 0 ${10 + 26 * glow}px ${C.orange}`}} />
          </span>
          {Q_AFTER}
        </div>
      </div>
      {/* rujukan */}
      <div style={{position: 'absolute', left: 70, right: 70, top: 1118, textAlign: 'center', opacity: refE, transform: `translateY(${(1 - refE) * 16}px)`}}>
        <div style={{...Arabic, fontSize: 44, color: C.gold, lineHeight: 1.2, textShadow: `0 0 18px ${C.orange}88`}}>{Q_REF}</div>
      </div>
      {/* linimasa nama */}
      <div style={{position: 'absolute', left: 80, right: 80, top: 1236, opacity: ease(cs(19) - 6, 10), ...Latin}}>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
          <div style={{fontWeight: 700, fontSize: 38, color: C.cream}}>al-‘Arabiyyah</div>
          <div style={{flex: 1, height: 6, margin: '0 22px', background: `linear-gradient(90deg, ${C.orange}, ${C.gold})`, borderRadius: 3, transform: `scaleX(${ease(cs(19) + 4, 22)})`, transformOrigin: 'left'}} />
          <div style={{fontWeight: 800, fontSize: 46, color: C.gold, opacity: ease(cs(19) + 20, 10), textShadow: `0 0 24px ${C.orange}`}}>Nahwu</div>
        </div>
        <div style={{textAlign: 'center', fontWeight: 500, fontSize: 30, color: C.dim, marginTop: 12, opacity: ease(cs(20), 12)}}>nama nahwu dikenal sepeninggalnya</div>
      </div>
      <Flash at={cs(15) + 2} color={C.gold} />
      <Burst at={cs(15) + 2} x={W / 2} y={340} n={24} power={380} />
    </SceneWrap>
  );
};

/* ───────── 6. DUA KUBU (fase retak → peta Basrah–Kufah) ───────── */
export const Kubu: React.FC<{dur: number}> = ({dur}) => {
  const {f, ease} = useAnim();
  const split = interpolate(f, [cs(22), cs(22) + 24], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  // peta hanya muncul saat naskah menyebut Basrah dan Kufah (klausa 23 dst.)
  const mapAt = cs(23) - 10;
  const mapIn = interpolate(f, [mapAt, mapAt + 22], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  const a = 1 - interpolate(f, [mapAt, mapAt + 16], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <SceneWrap dur={dur}>
      {a > 0.01 && (
        <AbsoluteFill style={{opacity: a}}>
          <Big text="BELUM SELESAI" at={cs(21)} y={560} size={110} color={C.cream} />
          {/* retakan */}
          <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
            <path d={`M ${W / 2} 280 L ${W / 2 - 40} 520 L ${W / 2 + 36} 760 L ${W / 2 - 30} 1000 L ${W / 2 + 20} 1250`} stroke={C.orange} strokeWidth={8} fill="none" strokeDasharray={1200} strokeDashoffset={1200 * (1 - split)} style={{filter: `drop-shadow(0 0 16px ${C.orange})`}} />
          </svg>
          <AbsoluteFill style={{opacity: split * 0.5, background: `linear-gradient(90deg, rgba(63,182,168,0.30) 0%, transparent 48%, transparent 52%, rgba(255,154,60,0.30) 100%)`}} />
          <Big text="DUA KUBU" at={cs(22) + 12} y={300} size={96} color={C.gold} />
          <Flash at={cs(22) + 6} color={C.orange} />
          <Burst at={cs(22) + 6} x={W / 2} y={760} n={26} color={C.orange} power={460} />
        </AbsoluteFill>
      )}
      {mapIn > 0.001 && (
        <AbsoluteFill style={{clipPath: `circle(${mapIn * 1500}px at ${W / 2}px 760px)`}}>
          <MapBasrahKufah dur={dur} />
        </AbsoluteFill>
      )}
      <Tag text="DUA KUBU" at={cs(21)} />
    </SceneWrap>
  );
};

/* ───────── 7a. KAIDAH MENUMPUK ───────── */
const TERMS = ['رَفْع', 'نَصْب', 'جَرّ', 'جَزْم', 'مُبْتَدَأ', 'خَبَر', 'فَاعِل', 'مَفْعُول', 'حَال', 'تَمْيِيز'];
export const Tumpuk: React.FC<{dur: number}> = ({dur}) => {
  const {f, ease, spr} = useAnim();
  const sink = ease(cs(33), 30);
  return (
    <SceneWrap dur={dur}>
      <Tag text="BERABAD-ABAD KEMUDIAN" at={cs(31)} />
      <Big text="KAIDAH MENUMPUK" at={cs(32)} y={290} size={96} color={C.gold} />
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, transform: `translateY(${sink * 40}px) rotate(${Math.sin(f / 5) * sink * 1.2}deg)`}}>
        {TERMS.map((t, i) => {
          const at = cs(31) + i * 9;
          const fall = interpolate(f, [at, at + 12], [-600, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
          const bounce = f > at + 12 ? Math.max(0, Math.sin((f - at - 12) / 2.2) * 10 * Math.exp(-(f - at - 12) / 8)) : 0;
          const row = i;
          const w = 640 - (i % 3) * 60;
          const x = W / 2 - w / 2 + ((i * 53) % 90) - 45;
          return (
            <div key={i} style={{position: 'absolute', left: x, width: w, top: 1180 - row * 76 + fall - bounce, height: 68, borderRadius: 14, background: i % 2 ? 'linear-gradient(90deg,#1b2f66,#26408a)' : 'linear-gradient(90deg,#4a2b0c,#7a4616)', border: `2px solid ${C.gold}99`, opacity: f >= at ? 1 : 0, ...Arabic, textAlign: 'center', fontSize: 50, color: C.cream, lineHeight: '66px', boxShadow: '0 8px 22px #0008'}}>
              {t}
            </div>
          );
        })}
      </div>
      <Big text="BERAT DIHAFAL" at={cs(33)} y={400} size={84} color={C.red} glow={false} />
    </SceneWrap>
  );
};

/* ───────── 7b. PETA: ANDALUSIA → DAMASKUS ───────── */
export {Peta} from './PetaAndalusia';
